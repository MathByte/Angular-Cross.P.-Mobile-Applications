/**
 * File Name: kkDAL.js
 *
 * Revision History:
 *       Khachig Kerbabian, 2022-02-21 : Created
 */



