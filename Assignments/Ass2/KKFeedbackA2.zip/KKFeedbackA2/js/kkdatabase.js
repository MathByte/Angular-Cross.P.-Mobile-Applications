/**
 * File Name: kkdatabse.js
 *
 * Revision History:
 *       Khachig Kerbabian, 2022-02-21 : Created
 */



